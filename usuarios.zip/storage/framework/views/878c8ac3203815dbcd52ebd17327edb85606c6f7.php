<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <a class="btn btn-primary" href="#addmesa">Añadir mesa</a>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>   
                    <?php endif; ?>
                    <?php for($i=1 ; $i<=15 ; $i++): ?>
                        <?php if($i < 10): ?>
                            <button id="bmesa<?php echo e($i); ?>" class="btn btn-outline-dark btn-social text-center rounded-square i" data-toggle="modal" data-target="#mesa<?php echo e($i); ?>" disabled="disabled">Mesa 0<?php echo e($i); ?></button>
                        <?php else: ?>
                            <button id="bmesa<?php echo e($i); ?>" class="btn btn-outline-dark btn-social text-center rounded-square i" data-toggle="modal" data-target="#mesa<?php echo e($i); ?>" disabled="disabled">Mesa <?php echo e($i); ?></button>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <?php
                    foreach ($lista as $listas){ 
                        echo "<script>";
                        echo "document.getElementById('bmesa$listas').disabled=false;";
                        echo "</script>";                
                    }
                ?> 
            </div>
        </div>
    </div>
</div>

<div id="addmesa" class="modalDialog">
	<div>
		<a href="#close" title="Close" class="close">X</a>
        <h2>Añadir mesa</h2>
        <?php echo e(Form::open(array('url' => '','method' => 'POST', 'onSubmit' => 'return hab_mesaG()'))); ?>

            <h5>Seleccione mesa.</h5>
            <?php echo e(Form::number('num', 1,array('id'=>'num','min'=>'1' ,'max'=>15))); ?>

            <h5>Seleccione sandwich.</h5>
            <?php echo e(Form::select('sandwich', $lista_platos ,null,['id'=>'sandwich'])); ?>

            
            <?php echo e(Form::submit('Habilitar mesa', array('class' => 'btn btn-primary'))); ?>

        <?php echo e(Form::close()); ?>

        <h3 id='ocupado'></h3>
        
	</div>
</div>

<?php
	foreach ($lista as $nummesa){
		echo "<div class='modal fade' id='mesa$nummesa' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>\n";
		echo "<div class='modal-dialog' role='document'>\n";
		echo "<div class='modal-content'>\n";
		echo "<div class='modal-header'>\n";
		echo "<button type='button' class='close' data-dismiss='modal' aria-label='Close'>\n";
		echo "<span aria-hidden='true'>&times;</span>\n";
		echo "</button>\n";
		echo "<h4 class='modal-title' id='myModalLabel'>Mesa $nummesa </h4>\n";
		echo "</div>\n";
		echo "<div class='modal-body'>\n";
		$j=0;
		$i=0;		
		foreach($num_mesa as $num){
			foreach($num_mesa[$j] as $numsito){
				if ($num_mesa[$j][$i] == $nummesa) {
                    echo "<p>";
					echo $comida_mesas[$j][$i]." ";
					echo " $".$precio_mesas[$j][$i];
                    echo "</p>";				
				}
				$i++;
			}
			$j++;
			$i=0;
		}	
		echo "</div>\n";
		echo "</div>\n";
		echo "</div>\n";
		echo "</div>\n";
	}
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>